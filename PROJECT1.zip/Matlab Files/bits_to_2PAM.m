function [x]=bits_to_2PAM(b)
    x=-2*b+1;
end